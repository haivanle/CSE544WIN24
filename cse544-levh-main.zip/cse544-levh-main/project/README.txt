Place your project milestones here, in pdf format:

    project1.pdf   -- project proposal
    project2.pdf   -- project milestone
    project4.pdf   -- (poster is optional)
    project5.pdf   -- final report

